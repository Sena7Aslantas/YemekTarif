package com.senaaslantas.yemektarifi

data class Tarifler(var yemek_adi:String,var yemek_tarif:String,var yemek_resim:String) {
}